# as in k-diffusion (sampling.py)
MIN_SEED = 0
MAX_SEED = 2**63 - 1

AUTH_FILENAME = 'auth.json'
